function verifyDisplayTableForm(){
  return true;
}

function verifyCreateTableForm(){
  return true;
}


function verifyAddRowForm(){
  return true;
}

function verifyDropForm(){
  return true;
}

function verifyPopulateForm(){
  return true;
}

